<?php
// Autoload layouts in this folder
investment_autoload_folder( 'templates/trx_team' );
?>