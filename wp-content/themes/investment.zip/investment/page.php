<?php
/**
 * Single Page
 */

get_template_part('single');
?>